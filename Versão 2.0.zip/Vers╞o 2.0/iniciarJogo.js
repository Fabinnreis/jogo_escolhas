function iniciarJogo(){
    return fase1();
}