/* Script de configuração do jogo */

/*
//Script de Início do Jogo
var inicioJogo = document.createElement('script');
inicioJogo.src = 'iniciarJogo.js';
document.head.appendChild(inicioJogo); 
*/


//Introdução do Jogo
var intro = document.createElement('script');
intro.src = 'introducao.js';
document.head.appendChild(intro);
//Altera background do body
document.body.style.backgroundColor = "#D3D3D3";

/*

//Fase1
var fase1 = document.createElement('script');
fase1.src = 'fase1.js';
document.head.appendChild(fase1);

//Fase2
var fase2 = document.createElement('script');
fase2.src = 'fase2.js';
document.head.appendChild(fase2);

//Fase3
var fase3 = document.createElement('script');
fase3.src = 'fase3.js' ;
document.head.appendChild(fase3);

//Fase4
var fase4 = document.createElement('script');
fase4.src = 'fase4.js';
document.head.appendChild(fase4);

//Fase5
var fase5 = document.createElement('script');
fase5.src = 'fase5.js';
document.head.appendChild(fase5);

//Fase6
var fase6 = document.createElement('script');
fase6.src = 'fase6.js';
document.head.appendChild(fase6);

//Fase7
var fase7 = document.createElement('script');
fase7.src = "fase7.js";
document.head.appendChild(fase7);

//Final do jogo
var fimJogo = document.createElement('script');
fimJogo.src = "fimJogo.js";
document.head.appendChild(fimjogo);

*/