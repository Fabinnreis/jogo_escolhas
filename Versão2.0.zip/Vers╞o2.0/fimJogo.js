function fimDeJogo(){
    alert("Ocorre o duelo final entre Yone e Shaka. O Samurai vence, liberta sua família, volta para sua vila natal e é honrado com elevação de grau no seu dojo. Virando assim um herói Samurai.");
    alert("Parabéns você zerou o jogo!");
    introducao();
}