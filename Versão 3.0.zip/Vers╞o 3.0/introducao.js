function introducao(){
    
    


    //Altera background do body
    document.body.style.backgroundImage = "url('gba.jpg')";
    //centraliza Background
    document.body.style.backgroundPosition = "center";
    //adiciona a propriedade flex
    document.body.style.display = "flex";
    //justifica conteudo da linha ao centro
    document.body.style.justifyContent = "center";
    //centraliza coluna no centro
    document.body.style.alignItems = "center";

    //------------------------ Caixa -----------------------------
    
    //cria uma caixa para exibir os elementos
    var caixa = document.createElement('div');
    //configura imagem de fundo da introdução
    caixa.style.backgroundImage = "url('cenarioIntro4.gif')";
    //centraliza imagam de fundo
    caixa.style.backgroundPosition = "center";
    //configura a largura
    caixa.style.width = "532px";
    //configura a altura
    caixa.style.height = "360px";

    //--------------- Paragrafo ----------------------------------
    
    //cria uma paragrafo para exibir o texto
    var paragrafo = document.createElement('p');
    //altera a cor do texto do paragrafo
    paragrafo.style.color = "#FFFFFF";
    paragrafo.style.fontSize = "1.4em";
    paragrafo.style.fontWeight = "bold";
    paragrafo.style.webkitTextStrokeWidth = "0.7px";
    paragrafo.style.webkitTextStrokeColor = "#000"; /* cor da borda */
    //cria o texto de introdução 
    var textoIntro = document.createTextNode("Yone vs dragõesaaa - na saga do tempo é uma narrativa de ficção e de feitos heroicos que se inicia na província Fukuoka, no Japão feudal, e o seu desenrolar acontece entre a vila Yoshinogari, nos tempos feudais, e no bairro da Liberdade, em 2100. A família do Samurai é sequestrada pelo seu ex-parceiro de dojo e ele precisa descobrir um jeito de salvá-la. Viagem no tempo, bruxaria? Como nosso herói fará para salvar sua família no futuro? \n\n" + "Digite 1 para Iniciar Jogo \n" + "Digite 2 para sair do jogo \n");
    
    //---------------- Botao ------------------------------

    //cria botao de escolha
    var botaoEscolha1 = document.createElement('button');
    //insere texto no botao
    botaoEscolha1.name = "inicioJogo";
    botaoEscolha1.innerText = "INICIAR JOGO";
    botaoEscolha1.setAttribute("onclick", "iniciarJogo()");
    botaoEscolha1.setAttribute("id", "btnEscolha1");
    botaoEscolha1.style.width = "100%";
    botaoEscolha1.style.height = "30px";

    
     
    //adiciona paragrafo na caixa
    caixa.appendChild(paragrafo);
    //adiciona o texto  no parágrafo
    paragrafo.appendChild(textoIntro);
    //adiciona botao de escolha
    caixa.appendChild(botaoEscolha1);
    

    document.body.appendChild(caixa);
    
    //------------------------- Eventos---------------------------------------------    
  /*  
    if (intro == 1){
        fase1();
    }else if (intro == 2){
        alert("Que pena! Volte se quiser!");
        introducao();
    }else{
        alert("Entrada inválida! Tente novamente");
        introducao();
    }
    */
}
introducao();

