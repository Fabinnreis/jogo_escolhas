function showCoords(event) {
    var x = event.clientX;
    var y = event.clientY;
    var coor = "X coords: " + x + ", Y coords: " + y;
    document.getElementById("demo").innerHTML = coor;
  }
  
  function getCoor(event) {  
    var x = event.clientX;
    var y = event.clientY;
    var coor = "X coords: " + x + ", Y coords: " + y;
    document.getElementById("demo2").innerHTML = coor;
  }

  var fundoMap = document.createElement('div');
  fundoMap.style.width = "100%";
  fundoMap.style.height = "800px";
  
  
  fundoMap.style.position = "absolute";
  //fundoMap.style.left = "0px";
  //fundoMap.style.top = "0px";

  fundoMap.setAttribute("usemap","#workmap");
  fundoMap.style.zIndex = "-1";
  fundoMap.style.border = "1px solid black"



  var map = document.createElement('map');
  map.setAttribute("name","workmap");
  var area = document.createElement('area');
  area.setAttribute("shape","circle");
  area.setAttribute("coords","337,300,44");
  area.setAttribute("alt","Botão de ação");
  area.setAttribute("href","#");
  

  
  

  document.body.appendChild(fundoMap);
  fundoMap.appendChild(map);
  map.appendChild(area);